@NamedQuery(name = "allMouse_1_0",
		query = "select m from ApplicationServer1 m")
package org.hibernate.ejb.test.pack.defaultpar_1_0;

import org.hibernate.annotations.NamedQuery;