//$Id: $
package org.hibernate.ejb.test.xml.sequences;

/**
 * @author Emmanuel Bernard
 */
public class Light {
	public String name;
	public String power;
}
