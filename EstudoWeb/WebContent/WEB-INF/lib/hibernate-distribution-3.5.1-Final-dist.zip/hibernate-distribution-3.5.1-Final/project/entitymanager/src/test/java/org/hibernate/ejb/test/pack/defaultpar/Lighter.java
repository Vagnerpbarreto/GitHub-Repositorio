//$Id: Lighter.java 15483 2008-11-03 14:25:59Z hardy.ferentschik $
package org.hibernate.ejb.test.pack.defaultpar;

/**
 * @author Emmanuel Bernard
 */
public class Lighter {
	public String name;
	public String power;
}
